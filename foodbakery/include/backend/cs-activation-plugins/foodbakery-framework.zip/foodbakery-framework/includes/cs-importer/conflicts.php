<?php
$conflicted_pages = array(
	"foodbakery" => array(
		"About Us",
		"Home",
	),
);